import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JSpinner;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class PetInfo extends JPanel {
	private static JLabel petinfo_main = new JLabel("��������");
	private static JLabel petinfo_name = new JLabel("�������ࣺ");
	private static JLabel petinfo_eat = new JLabel("ϲ��ʳ�");
	private static JLabel petinfo_drink = new JLabel("ϲ����Ʒ��");
	private static JLabel petinfo_live = new JLabel("ϲ�û�����");
	private static JLabel petinfo_hobby = new JLabel("ϲ����Ϊ��");
	private static JLabel petinfo_cost = new JLabel("����۸�");
	private static JLabel petinfo_number = new JLabel("����������");
	private static JSpinner petinfo_number_spinner = new JSpinner();
	private static JButton petinfo_addToCar = new JButton("���������ﳵ");
	private static JButton petinfo_checkCar = new JButton("�鿴���ﳵ");
	private static JButton petinfo_backToList = new JButton("�����б�");
	
	private String name;
	private String eat;
	private String drink;
	private String live;
	private String hobby;
	private String cost;

	public PetInfo() {
		// TODO �Զ����ɵĹ��캯�����
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
			Connection conn = DriverManager.getConnection(url);
			Statement stmt = conn.createStatement();
			String order = "select id,name,eat,drink,live,hobby,cost from 2014302580373_pet where name =\""+GUI.pet_name+"\"";
			ResultSet rs = stmt.executeQuery(order);
			while(rs.next())
			{
				name = "�������ࣺ"+rs.getObject(2);
				eat = "ϲ��ʳ�"+rs.getObject(3);
				drink = "ϲ����Ʒ��"+rs.getObject(4);
				live = "ϲ�û�����"+rs.getObject(5);
				hobby = "ϲ����Ϊ��"+rs.getObject(6);
				cost = "����۸�"+rs.getObject(7);
			}

			this.setSize(400, 500);
			this.setLayout(null);
			
			petinfo_main.setHorizontalAlignment(SwingConstants.CENTER);
			petinfo_main.setFont(new Font("����", Font.PLAIN, 20));
			petinfo_main.setSize(80, 21);
			petinfo_main.setLocation(145, 36);
			this.add(petinfo_main);
			petinfo_name.setText(name);
			petinfo_name.setLocation(107, 76);
			petinfo_name.setFont(new Font("����", Font.PLAIN, 16));
			petinfo_name.setSize(220, 21);
			this.add(petinfo_name);
			petinfo_eat.setText(eat);
			petinfo_eat.setLocation(107, 112);
			petinfo_eat.setFont(new Font("����", Font.PLAIN, 16));
			petinfo_eat.setSize(220, 21);
			this.add(petinfo_eat);
			petinfo_drink.setText(drink);
			petinfo_drink.setFont(new Font("����", Font.PLAIN, 16));
			petinfo_drink.setSize(220, 21);
			petinfo_drink.setLocation(107, 148);
			this.add(petinfo_drink);
			petinfo_live.setText(live);
			petinfo_live.setFont(new Font("����", Font.PLAIN, 16));
			petinfo_live.setSize(265, 21);
			petinfo_live.setLocation(107, 184);
			this.add(petinfo_live);
			petinfo_hobby.setText(hobby);
			petinfo_hobby.setFont(new Font("����", Font.PLAIN, 16));
			petinfo_hobby.setSize(220, 21);
			petinfo_hobby.setLocation(107, 220);
			this.add(petinfo_hobby);
			petinfo_cost.setText(cost);
			petinfo_cost.setFont(new Font("����", Font.PLAIN, 16));
			petinfo_cost.setSize(160, 21);
			petinfo_cost.setLocation(107, 256);
			this.add(petinfo_cost);
			petinfo_number.setFont(new Font("����", Font.PLAIN, 16));
			petinfo_number.setSize(80, 21);
			petinfo_number.setLocation(107, 292);
			this.add(petinfo_number);
			petinfo_number_spinner.setFont(new Font("����", Font.PLAIN, 16));
			petinfo_number_spinner.setBounds(196, 292, 71, 22);
			this.add(petinfo_number_spinner);
			petinfo_addToCar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					if(!petinfo_number_spinner.getValue().equals(0))
					{
						GUI.buying = GUI.pet_name+"\t*"+petinfo_number_spinner.getValue()+"\n";
						GUI.buyingAll += GUI.buying;
						GUI.buying = "";
						petinfo_number_spinner.setValue(0);					
					}
				}
			});
			petinfo_addToCar.setFont(new Font("����", Font.PLAIN, 16));
			petinfo_addToCar.setSize(150, 27);
			petinfo_addToCar.setLocation(110, 335);
			this.add(petinfo_addToCar);
			petinfo_checkCar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					ShoppingCar shoppingcar = new ShoppingCar();
					GUI.getFrame().setContentPane(shoppingcar);
				}
			});
			petinfo_checkCar.setFont(new Font("����", Font.PLAIN, 16));
			petinfo_checkCar.setSize(150, 27);
			petinfo_checkCar.setLocation(110, 371);
			this.add(petinfo_checkCar);
			petinfo_backToList.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					GUI.setPanel(GUI.getFrame(), GUI.p_petlist);
				}
			});
			petinfo_backToList.setFont(new Font("����", Font.PLAIN, 16));
			petinfo_backToList.setSize(150, 27);
			petinfo_backToList.setLocation(110, 408);
			this.add(petinfo_backToList);

		} catch (ClassNotFoundException | SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}

	}
}
