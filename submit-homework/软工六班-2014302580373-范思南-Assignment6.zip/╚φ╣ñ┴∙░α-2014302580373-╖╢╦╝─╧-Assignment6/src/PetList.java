import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PetList extends JPanel
{
	private static JLabel petlist_main = new JLabel("�����б�");
	private static JButton petlist_dog = new JButton("��");
	private static JButton petlist_cat = new JButton("è");
	private static JButton petlist_turtle = new JButton("����");
	private static JButton petlist_parrot = new JButton("����");
	private static JButton petlist_hamster = new JButton("����");
	private static JButton petlist_squirrel = new JButton("����");
	private static JButton petlist_rabbit = new JButton("����");
	private static JButton petlist_snake = new JButton("��");
	private static JButton petlist_lizard = new JButton("����");
	private static JButton petlist_fish = new JButton("��");
	private static JButton petlist_myna = new JButton("�˸�");
	private static JButton petlist_canary = new JButton("��˿ȸ");
	private static JButton petlist_backToLogin = new JButton("ע���˻�");
	
	public PetList() {
		// TODO �Զ����ɵĹ��캯�����
		this.setSize(400, 500);
		this.setLayout(null);
		
		petlist_main.setHorizontalAlignment(SwingConstants.CENTER);
		petlist_main.setFont(new Font("����", Font.PLAIN, 20));
		petlist_main.setSize(80, 21);
		petlist_main.setLocation(145, 36);	
		this.add(petlist_main);
		petlist_dog.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				GUI.pet_name = "dog";
				PetInfo petinfo = new PetInfo();
				GUI.getFrame().setContentPane(petinfo);
			}
		});
		petlist_dog.setLocation(55, 78);
		petlist_dog.setFont(new Font("����", Font.PLAIN, 16));
		petlist_dog.setSize(80, 27);
		this.add(petlist_dog);
		petlist_cat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.pet_name = "cat";
				PetInfo petinfo = new PetInfo();
				GUI.getFrame().setContentPane(petinfo);
			}
		});
		petlist_cat.setLocation(145, 78);
		petlist_cat.setFont(new Font("����", Font.PLAIN, 16));
		petlist_cat.setSize(80, 27);
		this.add(petlist_cat);
		petlist_turtle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.pet_name = "turtle";
				PetInfo petinfo = new PetInfo();
				GUI.getFrame().setContentPane(petinfo);
			}
		});
		petlist_turtle.setLocation(235, 78);
		petlist_turtle.setFont(new Font("����", Font.PLAIN, 16));
		petlist_turtle.setSize(80, 27);
		this.add(petlist_turtle);
		petlist_parrot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.pet_name = "parrot";
				PetInfo petinfo = new PetInfo();
				GUI.getFrame().setContentPane(petinfo);
			}
		});
		petlist_parrot.setLocation(55, 138);
		petlist_parrot.setFont(new Font("����", Font.PLAIN, 16));
		petlist_parrot.setSize(80, 27);
		this.add(petlist_parrot);
		petlist_hamster.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.pet_name = "hamster";
				PetInfo petinfo = new PetInfo();
				GUI.getFrame().setContentPane(petinfo);
			}
		});
		petlist_hamster.setLocation(145, 138);
		petlist_hamster.setFont(new Font("����", Font.PLAIN, 16));
		petlist_hamster.setSize(80, 27);
		this.add(petlist_hamster);
		petlist_squirrel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.pet_name = "squirrel";
				PetInfo petinfo = new PetInfo();
				GUI.getFrame().setContentPane(petinfo);
			}
		});
		petlist_squirrel.setLocation(235, 138);
		petlist_squirrel.setFont(new Font("����", Font.PLAIN, 16));
		petlist_squirrel.setSize(80, 27);
		this.add(petlist_squirrel);
		petlist_rabbit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.pet_name = "rabbit";
				PetInfo petinfo = new PetInfo();
				GUI.getFrame().setContentPane(petinfo);
			}
		});
		petlist_rabbit.setLocation(55, 198);
		petlist_rabbit.setFont(new Font("����", Font.PLAIN, 16));
		petlist_rabbit.setSize(80, 27);
		this.add(petlist_rabbit);
		petlist_snake.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.pet_name = "snake";
				PetInfo petinfo = new PetInfo();
				GUI.getFrame().setContentPane(petinfo);
			}
		});
		petlist_snake.setLocation(145, 198);
		petlist_snake.setFont(new Font("����", Font.PLAIN, 16));
		petlist_snake.setSize(80, 27);
		this.add(petlist_snake);
		petlist_lizard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.pet_name = "lizard";
				PetInfo petinfo = new PetInfo();
				GUI.getFrame().setContentPane(petinfo);
			}
		});
		petlist_lizard.setLocation(235, 198);
		petlist_lizard.setFont(new Font("����", Font.PLAIN, 16));
		petlist_lizard.setSize(80, 27);
		this.add(petlist_lizard);
		petlist_fish.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.pet_name = "fish";
				PetInfo petinfo = new PetInfo();
				GUI.getFrame().setContentPane(petinfo);
			}
		});
		petlist_fish.setLocation(55, 258);
		petlist_fish.setFont(new Font("����", Font.PLAIN, 16));
		petlist_fish.setSize(80, 27);
		this.add(petlist_fish);
		petlist_myna.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.pet_name = "myna";
				PetInfo petinfo = new PetInfo();
				GUI.getFrame().setContentPane(petinfo);
			}
		});
		petlist_myna.setLocation(145, 258);
		petlist_myna.setFont(new Font("����", Font.PLAIN, 16));
		petlist_myna.setSize(80, 27);
		this.add(petlist_myna);
		petlist_canary.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.pet_name = "canary";
				PetInfo petinfo = new PetInfo();
				GUI.getFrame().setContentPane(petinfo);
			}
		});
		petlist_canary.setLocation(235, 258);
		petlist_canary.setFont(new Font("����", Font.PLAIN, 16));
		petlist_canary.setSize(82, 27);
		this.add(petlist_canary);
		petlist_backToLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.buyingAll = "";
				GUI.setPanel(GUI.getFrame(), GUI.p_login);
			}
		});
		petlist_backToLogin.setLocation(137, 333);
		petlist_backToLogin.setFont(new Font("����", Font.PLAIN, 16));
		petlist_backToLogin.setSize(100, 27);
		this.add(petlist_backToLogin);
	}
}
