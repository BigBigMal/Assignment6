import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;

public class GUI extends JFrame
{
	private static JFrame frame;
	private static Login login = new Login();
	private static Register register = new Register();
	private static PetList petlist = new PetList();
//	private static PetInfo petinfo = new PetInfo();
//	private static ShoppingCar shoppingcar = new ShoppingCar();
	
	public static int p_login = 1;
	public static int p_register = 2;
	public static int p_petlist = 3;
	public static int p_petinfo = 4;
	public static int p_shoppingcar = 5;
	public static String pet_name;
	public static String buying = "";
	public static String buyingAll = "";
	
	public static void main(String[] args) 
	{
		frame = new GUI();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 500);
		frame.setTitle("�����");
		frame.setVisible(true);
	}
	
	public GUI() {
		// TODO �Զ����ɵĹ��캯�����
		super();
		this.setResizable(false);
		this.add(login);
		this.add(register);
		setPanel(this, p_login);
		
	}
	
	public static void setPanel(JFrame frame, int i) 
	{
		switch(i)
		{
		case 1:
			frame.setContentPane(login);
			break;
		case 2:
			frame.setContentPane(register);
			break;
		case 3:
			frame.setContentPane(petlist);
			break;
//		case 4:
//			frame.setContentPane(petinfo);
//			break;
//		case 5:
//			frame.setContentPane(shoppingcar);
//			break;
		default:
			break;
		}	
	}
	
	public static JFrame getFrame()
	{
		return frame;
	}
	
//	public static ResultSet connectMYSQL()
//	{
//		ResultSet rs = null;
//		try 
//		{
//			Class.forName("com.mysql.jdbc.Driver");
//			String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
//			Connection conn = DriverManager.getConnection(url);
//			Statement stmt = conn.createStatement();
//			String order = "select name,eat,drink,live,hobby,cost from 2014302580373_pet where name is"+pet_name;
//			rs = stmt.executeQuery(order);
//			
//		} catch (ClassNotFoundException | SQLException e) {
//			// TODO �Զ����ɵ� catch ��
//			e.printStackTrace();
//		}
//		return rs;
//	}

}
