import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ShoppingCar extends JPanel
{
	private static JLabel shoppingcar_main = new JLabel("����С��");
	private static JTextArea shoppingcar_buying = new JTextArea();
	private static JScrollPane shoppingcar_scrollpane = new JScrollPane(shoppingcar_buying);
	private static JButton shoppingcar_ensure = new JButton("ȷ������");
	private static JButton shoppingcar_backtolist = new JButton("���س����б�");
	
	public ShoppingCar() {
		// TODO �Զ����ɵĹ��캯�����
		this.setSize(400, 500);
		this.setLayout(null);
		
		shoppingcar_main.setFont(new Font("����", Font.PLAIN, 20));
		shoppingcar_main.setHorizontalAlignment(SwingConstants.CENTER);
		shoppingcar_main.setSize(80, 21);
		shoppingcar_main.setLocation(145, 36);
		this.add(shoppingcar_main);
		shoppingcar_buying.setFont(new Font("Monospaced", Font.PLAIN, 16));
		shoppingcar_buying.setText(GUI.buyingAll);
		shoppingcar_scrollpane.setLocation(45, 80);
		shoppingcar_scrollpane.setSize(303, 271);
		this.add(shoppingcar_scrollpane);
		shoppingcar_ensure.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"��ϲ�������ѹ���ɹ���","����ɹ�",JOptionPane.INFORMATION_MESSAGE);
				GUI.buyingAll = "";
				shoppingcar_buying.setText("�����ѹ���ɹ���");
			}
		});
		shoppingcar_ensure.setFont(new Font("����", Font.PLAIN, 16));
		shoppingcar_ensure.setLocation(134, 375);
		shoppingcar_ensure.setSize(130, 27);
		this.add(shoppingcar_ensure);
		shoppingcar_backtolist.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				GUI.setPanel(GUI.getFrame(), GUI.p_petlist);
			}
		});
		shoppingcar_backtolist.setLocation(134, 412);
		shoppingcar_backtolist.setFont(new Font("����", Font.PLAIN, 16));
		shoppingcar_backtolist.setSize(130, 27);
		this.add(shoppingcar_backtolist);
	}
}
