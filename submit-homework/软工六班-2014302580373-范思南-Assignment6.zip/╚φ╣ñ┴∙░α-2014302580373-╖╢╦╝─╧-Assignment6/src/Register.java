import java.awt.Font;

import javax.mail.MessagingException;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import org.reflections.Reflections;

import iss.java.mail.IMailService;

import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.Set;
import java.awt.event.ActionEvent;

public class Register extends JPanel {
	private static JLabel register_main = new JLabel("��ӭע��");
	private static JLabel register_username = new JLabel("�û���");
	private static JTextField register_username_blank = new JTextField();
	private static JLabel register_keyword1 = new JLabel("��������");
	private static JPasswordField register_keyword1_blank = new JPasswordField();
	private static JLabel register_keyword2 = new JLabel("ȷ������");
	private static JPasswordField register_keyword2_blank = new JPasswordField();
	private static JLabel register_email = new JLabel("����");
	private static JTextField register_email_blank = new JTextField();
	private static JButton register_sendEmail = new JButton("������֤�ʼ�");
	private static JLabel register_emailKey = new JLabel("�����ʼ�����֤��");
	private static JTextField register_emailKey_blank = new JTextField();
	private static JButton register_ensure = new JButton("ע��");
	private static JButton register_unsure = new JButton("ȡ��");
	private static int random;

	public Register() {
		// TODO �Զ����ɵĹ��캯�����
		this.setSize(400, 500);
		this.setLayout(null);

		register_main.setHorizontalAlignment(SwingConstants.CENTER);
		register_main.setFont(new Font("����", Font.PLAIN, 20));
		register_main.setSize(80, 21);
		register_main.setLocation(145, 36);
		this.add(register_main);
		register_username.setHorizontalAlignment(SwingConstants.CENTER);
		register_username.setFont(new Font("����", Font.PLAIN, 16));
		register_username.setSize(64, 21);
		register_username.setLocation(51, 79);
		this.add(register_username);
		register_username_blank.setFont(new Font("����", Font.PLAIN, 16));
		register_username_blank.setSize(162, 21);
		register_username_blank.setLocation(125, 79);
		this.add(register_username_blank);
		register_keyword1.setFont(new Font("����", Font.PLAIN, 16));
		register_keyword1.setHorizontalAlignment(SwingConstants.CENTER);
		register_keyword1.setSize(64, 21);
		register_keyword1.setLocation(51, 124);
		this.add(register_keyword1);
		register_keyword1_blank.setFont(new Font("����", Font.PLAIN, 16));
		register_keyword1_blank.setLocation(125, 125);
		register_keyword1_blank.setSize(162, 21);
		this.add(register_keyword1_blank);
		register_keyword2.setLocation(51, 169);
		register_keyword2.setFont(new Font("����", Font.PLAIN, 16));
		register_keyword2.setHorizontalAlignment(SwingConstants.CENTER);
		register_keyword2.setSize(64, 21);
		this.add(register_keyword2);
		register_keyword2_blank.setFont(new Font("����", Font.PLAIN, 16));
		register_keyword2_blank.setLocation(125, 170);
		register_keyword2_blank.setSize(162, 21);
		this.add(register_keyword2_blank);
		register_email.setLocation(51, 214);
		register_email.setFont(new Font("����", Font.PLAIN, 16));
		register_email.setHorizontalAlignment(SwingConstants.CENTER);
		register_email.setSize(64, 21);
		this.add(register_email);
		register_email_blank.setFont(new Font("����", Font.PLAIN, 16));
		register_email_blank.setLocation(125, 215);
		register_email_blank.setSize(162, 21);
		this.add(register_email_blank);
		register_sendEmail.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Reflections reflections = new Reflections("iss.java.mail");
					Set<Class<? extends IMailService>> impls = reflections.getSubTypesOf(IMailService.class);
					Class<? extends IMailService> homework = impls.iterator().next();
					IMailService service = homework.newInstance();
					service.connect();
					random = new Random().nextInt(900000)+100000;
					service.send(register_email_blank.getText(), "����\"�����\"����֤�ļ�", "��֤�룺"+Integer.toString(random));
				} catch (MessagingException | InstantiationException
						| IllegalAccessException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
		});
		register_sendEmail.setFont(new Font("����", Font.PLAIN, 16));
		register_sendEmail.setLocation(103, 255);
		register_sendEmail.setSize(162, 27);
		this.add(register_sendEmail);
		register_emailKey.setFont(new Font("����", Font.PLAIN, 16));
		register_emailKey.setLocation(51, 298);
		register_emailKey.setSize(128, 21);
		this.add(register_emailKey);
		register_emailKey_blank.setFont(new Font("����", Font.PLAIN, 16));
		register_emailKey_blank.setLocation(189, 299);
		register_emailKey_blank.setSize(98, 21);
		this.add(register_emailKey_blank);
		register_ensure.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String key1 = new String(register_keyword1_blank.getPassword());
				String key2 = new String(register_keyword2_blank.getPassword());
				if(!key1.equals(key2))
				{
					JOptionPane.showMessageDialog(null,"������������벻ͬ��","����",JOptionPane.ERROR_MESSAGE);
				}
				if(!Integer.toString(random).equals(register_emailKey_blank.getText()))
				{
					JOptionPane.showMessageDialog(null,"��֤���������","����",JOptionPane.ERROR_MESSAGE);
				}
				if(key1.equals(key2) && Integer.toString(random).equals(register_emailKey_blank.getText()))
				{
					try {
						Class.forName("com.mysql.jdbc.Driver");
						String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
						Connection conn = DriverManager.getConnection(url);
						Statement stmt = conn.createStatement();
						String order = "insert into 2014302580373_user(name,keyword)values(\""+register_username_blank.getText()+"\",\""+key1+"\")";
						stmt.executeUpdate(order);
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
					JOptionPane.showMessageDialog(null,"��ϲ���˻���ע��ɹ���","ע��ɹ�",JOptionPane.INFORMATION_MESSAGE);
					GUI.setPanel(GUI.getFrame(), GUI.p_login);
				}
			}
		});
		register_ensure.setFont(new Font("����", Font.PLAIN, 16));
		register_ensure.setLocation(87, 337);
		register_ensure.setSize(80, 27);
		this.add(register_ensure);
		register_unsure.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				GUI.setPanel(GUI.getFrame(), GUI.p_login);
			}
		});
		register_unsure.setLocation(189, 337);
		register_unsure.setFont(new Font("����", Font.PLAIN, 16));
		register_unsure.setSize(80, 27);
		this.add(register_unsure);
	}
}
