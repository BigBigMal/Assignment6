import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Login extends JPanel {
	private static JLabel login_main = new JLabel("��ӭ��½");
	private static JLabel login_username = new JLabel("�û���");
	private static JTextField login_username_blank = new JTextField();
	private static JLabel login_keyword = new JLabel("����");
	private static JPasswordField login_keyword_blank = new JPasswordField();
	private static JButton login_register_button = new JButton("ע��");
	private static JButton login_login_button = new JButton("��½");

	public Login() {
		// TODO �Զ����ɵĹ��캯�����
		this.setSize(400, 500);
		this.setLayout(null);

		login_main.setHorizontalAlignment(SwingConstants.CENTER);
		login_main.setFont(new Font("����", Font.PLAIN, 20));
		login_main.setSize(80, 21);
		login_main.setLocation(145, 36);
		this.add(login_main);
		login_username.setHorizontalAlignment(SwingConstants.CENTER);
		login_username.setFont(new Font("����", Font.PLAIN, 16));
		login_username.setSize(48, 21);
		login_username.setLocation(67, 79);
		this.add(login_username);
		login_username_blank.setFont(new Font("����", Font.PLAIN, 16));
		login_username_blank.setSize(162, 21);
		login_username_blank.setLocation(125, 79);
		this.add(login_username_blank);
		login_keyword.setFont(new Font("����", Font.PLAIN, 16));
		login_keyword.setHorizontalAlignment(SwingConstants.CENTER);
		login_keyword.setSize(48, 21);
		login_keyword.setLocation(67, 124);
		this.add(login_keyword);
		login_keyword_blank.setSize(162, 21);
		login_keyword_blank.setLocation(125, 125);
		this.add(login_keyword_blank);
		login_register_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				GUI.setPanel(GUI.getFrame(), GUI.p_register);
			}
		});
		login_register_button.setFont(new Font("����", Font.PLAIN, 16));
		login_register_button.setSize(80, 27);
		login_register_button.setLocation(87, 171);
		this.add(login_register_button);
		login_login_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String mysql_username = null;
				String mysql_keyword = null;
				String input_keyword = new String(login_keyword_blank.getPassword());

				try {
					Class.forName("com.mysql.jdbc.Driver");

					String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
					Connection conn = DriverManager.getConnection(url);
					Statement stmt = conn.createStatement();
					String order = "select name,keyword from 2014302580373_user where name =\"" + login_username_blank.getText()
							+ "\"";
					ResultSet rs = stmt.executeQuery(order);
					while (rs.next()) {
						mysql_username = rs.getString(1);
						mysql_keyword = rs.getString(2);
					}

					if (!input_keyword.equals(mysql_keyword)) {
						JOptionPane.showMessageDialog(null, "�û������������", "����", JOptionPane.ERROR_MESSAGE);
						login_keyword_blank.setText("");
					}
					if (login_username_blank.getText().equals(mysql_username) && input_keyword.equals(mysql_keyword)) {
						JOptionPane.showMessageDialog(null, "��ϲ���˻��ѳɹ���½��", "��½�ɹ�", JOptionPane.INFORMATION_MESSAGE);
						login_keyword_blank.setText("");
						GUI.setPanel(GUI.getFrame(), GUI.p_petlist);
					}

				} catch (ClassNotFoundException | SQLException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
		});
		login_login_button.setFont(new Font("����", Font.PLAIN, 16));
		login_login_button.setSize(80, 27);
		login_login_button.setLocation(207, 172);
		this.add(login_login_button);
	}
}
