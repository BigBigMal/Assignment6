﻿# Host: localhost  (Version: 5.5.40)
# Date: 2015-11-21 17:32:18
# Generator: MySQL-Front 5.3  (Build 4.120)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "2014302580373_pet"
#

CREATE TABLE `2014302580373_pet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `eat` varchar(255) NOT NULL DEFAULT '',
  `drink` varchar(255) NOT NULL DEFAULT '',
  `live` varchar(255) NOT NULL DEFAULT '',
  `hobby` varchar(255) NOT NULL DEFAULT '',
  `cost` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

#
# Data for table "2014302580373_pet"
#

INSERT INTO `2014302580373_pet` VALUES (1,'dog','bone','water','ground','play','400'),(2,'cat','fish','milk','roof','hug','450'),(3,'turtle','fish,shrimp','sea water','sea water','bask','150'),(4,'parrot','nuts,seeds','water','tree','fly','800'),(5,'hamster','Sunflower seed','water','corner','eat','10'),(6,'squirrel','pine cone','water','tree hole,underground','play','320'),(7,'rabbit','carrot','water','grassland,underground','eat','30'),(8,'snake','mouse','water','hole','bask','280'),(9,'lizard','bug','water','tree','bask','1000'),(10,'fish','aquatic plant','water','water','swim','25'),(11,'myna','earthworm','water','tree','fly','890'),(12,'canary','millet','water','tree','sing','1200');
